#
# Tina4 - This is not a 4ramework.
# Copy-right 2007 - current Tina4
# License: MIT https://opensource.org/licenses/MIT
#

DEBUG_INFO = 0
DEBUG_WARNING = 1
DEBUG_DEBUG = 2